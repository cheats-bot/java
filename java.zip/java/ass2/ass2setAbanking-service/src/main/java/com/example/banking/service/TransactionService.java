package com.example.banking.service;

import com.example.banking.model.Transaction;
import com.example.banking.repo.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    public Optional<Transaction> getTransactionById(Long id) {
        return transactionRepository.findById(id);
    }

    public Transaction addTransaction(Transaction transaction) {
        return transactionRepository.save(transaction);
    }

    public Transaction updateTransaction(Long id, Transaction updatedTransaction) {
        Transaction existing = transactionRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Transaction not found"));
        existing.setFromAccNo(updatedTransaction.getFromAccNo());
        existing.setToAccNo(updatedTransaction.getToAccNo());
        existing.setAmount(updatedTransaction.getAmount());
        existing.setStatus(updatedTransaction.getStatus());
        existing.setTimestamp(updatedTransaction.getTimestamp());
        return transactionRepository.save(existing);
    }

    public void deleteTransaction(Long id) {
        transactionRepository.deleteById(id);
    }

    public Optional<Transaction> getTransactionByStatus(String status) {
        return transactionRepository.findByStatus(status);
    }
}