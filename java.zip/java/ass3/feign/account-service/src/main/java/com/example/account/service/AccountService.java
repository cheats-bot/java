package com.example.account.service;

import com.example.account.TransactionFeignClient;
import com.example.account.model.Account;
import com.example.account.model.TransactionResponse;
import com.example.account.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionFeignClient transactionFeignClient;

    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }

    public Optional<Account> getAccountById(Long id) {
        return accountRepository.findById(id);
    }

    public Account addAccount(Account account) {
        return accountRepository.save(account);
    }

    public List<TransactionResponse> getAllTransactions() {
        return transactionFeignClient.getAllTransactions();
    }

    public TransactionResponse addTransaction(TransactionResponse transaction) {
        return transactionFeignClient.addTransaction(transaction);
    }
}