package com.example.order.service;

import com.example.order.InventoryFeignClient;
import com.example.order.model.InventoryResponse;
import com.example.order.model.Order;
import com.example.order.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private InventoryFeignClient inventoryFeignClient;

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    public Order addOrder(Order order) {
        return orderRepository.save(order);
    }

    public List<InventoryResponse> getAllInventory() {
        return inventoryFeignClient.getAllInventory();
    }

    public InventoryResponse addInventory(InventoryResponse inventory) {
        return inventoryFeignClient.addInventory(inventory);
    }
}