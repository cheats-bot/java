package com.example.order.controller;

import com.example.order.model.InventoryResponse;
import com.example.order.model.Order;
import com.example.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/add")
    public ResponseEntity<Order> addOrder(@RequestBody Order order) {
        return ResponseEntity.status(201)
                .body(orderService.addOrder(order));
    }

    @GetMapping("/inventory")
    public List<InventoryResponse> getAllInventory() {
        return orderService.getAllInventory();
    }

    @PostMapping("/inventory")
    public ResponseEntity<InventoryResponse> addInventory(
            @RequestBody InventoryResponse inventory) {
        return ResponseEntity.status(201)
                .body(orderService.addInventory(inventory));
    }
}