package com.example.order;

import com.example.order.model.InventoryResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.List;

@FeignClient(name = "inventory-service")
public interface InventoryFeignClient {

    @GetMapping("/inventory")
    List<InventoryResponse> getAllInventory();

    @PostMapping("/inventory")
    InventoryResponse addInventory(@RequestBody InventoryResponse inventory);
}