package com.example.account.controller;

import com.example.account.model.Account;
import com.example.account.model.TransactionResponse;
import com.example.account.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @GetMapping
    public List<Account> getAllAccounts() {
        return accountService.getAllAccounts();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Account> getAccountById(@PathVariable Long id) {
        return accountService.getAccountById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/add")
    public ResponseEntity<Account> addAccount(@RequestBody Account account) {
        return ResponseEntity.status(201).body(accountService.addAccount(account));
    }

    @GetMapping("/transactions")
    public List<TransactionResponse> getAllTransactions() {
        return accountService.getAllTransactions();
    }

    @PostMapping("/transactions")
    public ResponseEntity<TransactionResponse> addTransaction(@RequestBody TransactionResponse transaction) {
        return ResponseEntity.status(201).body(accountService.addTransaction(transaction));
    }
}