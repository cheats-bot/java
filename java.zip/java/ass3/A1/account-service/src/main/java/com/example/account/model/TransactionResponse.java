package com.example.account.model;

import java.time.LocalDateTime;

public class TransactionResponse {

    private Long id;
    private String fromAccNo;
    private String toAccNo;
    private double amount;
    private String status;
    private LocalDateTime timestamp;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFromAccNo() { return fromAccNo; }
    public void setFromAccNo(String fromAccNo) { this.fromAccNo = fromAccNo; }

    public String getToAccNo() { return toAccNo; }
    public void setToAccNo(String toAccNo) { this.toAccNo = toAccNo; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}