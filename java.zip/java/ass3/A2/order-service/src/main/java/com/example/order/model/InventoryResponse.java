package com.example.order.model;

public class InventoryResponse {

    private Long id;
    private String skuCode;
    private int qty;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSkuCode() { return skuCode; }
    public void setSkuCode(String skuCode) { this.skuCode = skuCode; }

    public int getQty() { return qty; }
    public void setQty(int qty) { this.qty = qty; }
}