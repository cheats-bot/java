package com.example.order.service;

import com.example.order.InventoryFeignClient;
import com.example.order.model.InventoryResponse;
import com.example.order.model.Order;
import com.example.order.repository.OrderRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private InventoryFeignClient inventoryFeignClient;

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    public Order addOrder(Order order) {
        return orderRepository.save(order);
    }

    @CircuitBreaker(name = "inventoryBreaker", fallbackMethod = "fallbackGetInventory")
    public List<InventoryResponse> getAllInventory() {
        return inventoryFeignClient.getAllInventory();
    }

    public List<InventoryResponse> fallbackGetInventory(Exception ex) {
        System.out.println("Inventory service is down! Returning empty list.");
        return new ArrayList<>();
    }

    @CircuitBreaker(name = "inventoryBreaker", fallbackMethod = "fallbackAddInventory")
    public InventoryResponse addInventory(InventoryResponse inventory) {
        return inventoryFeignClient.addInventory(inventory);
    }

    public InventoryResponse fallbackAddInventory(InventoryResponse inventory, Exception ex) {
        System.out.println("Inventory service is down! Cannot add inventory.");
        InventoryResponse fallback = new InventoryResponse();
        fallback.setSkuCode("UNAVAILABLE");
        fallback.setQty(0);
        return fallback;
    }
}