package com.example.account;

import com.example.account.model.TransactionResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.List;

@FeignClient(name = "transaction-service")
public interface TransactionFeignClient {

    @GetMapping("/transactions")
    List<TransactionResponse> getAllTransactions();

    @PostMapping("/transactions")
    TransactionResponse addTransaction(@RequestBody TransactionResponse transaction);
}