package com.example.account.service;

import com.example.account.TransactionFeignClient;
import com.example.account.model.Account;
import com.example.account.model.TransactionResponse;
import com.example.account.repository.AccountRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionFeignClient transactionFeignClient;

    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }

    public Optional<Account> getAccountById(Long id) {
        return accountRepository.findById(id);
    }

    public Account addAccount(Account account) {
        return accountRepository.save(account);
    }

    @CircuitBreaker(name = "transactionBreaker", fallbackMethod = "fallbackGetTransactions")
    public List<TransactionResponse> getAllTransactions() {
        return transactionFeignClient.getAllTransactions();
    }

    public List<TransactionResponse> fallbackGetTransactions(Exception ex) {
        System.out.println("Transaction service is down! Returning empty list.");
        return new ArrayList<>();
    }

    @CircuitBreaker(name = "transactionBreaker", fallbackMethod = "fallbackAddTransaction")
    public TransactionResponse addTransaction(TransactionResponse transaction) {
        return transactionFeignClient.addTransaction(transaction);
    }

    public TransactionResponse fallbackAddTransaction(TransactionResponse transaction, Exception ex) {
        System.out.println("Transaction service is down! Cannot add transaction.");
        TransactionResponse fallback = new TransactionResponse();
        fallback.setStatus("FAILED - Service Unavailable");
        return fallback;
    }
}